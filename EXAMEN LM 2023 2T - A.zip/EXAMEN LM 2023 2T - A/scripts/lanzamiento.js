window.onload=function(){
    let f=document.intro;
    f.onsubmit=Funcionamiento;   
    f.mundial.oninput=ValidarAno;
}
function ValidarAno(){
    let f=document.intro;
    if(!/^19[3-9][0-9]$|^20[0-2][0-9]$|^2030$/.test(f.mundial.value)){
        f.mundial.setCustomValidity("El campo año no es válido..");
        f.mundial.style.backgroundColor="red";
    }
    else{
        f.mundial.setCustomValidity("");
        f.mundial.style.backgroundColor="white";
    }
}
function Funcionamiento(){
    let f=document.intro;
    let G1=f.goles_1;
    let G2=f.goles_2;

    if(isNaN(G1.value)||!/^[2-9]$/.test(G1.value)){
        alert("Formulario no completo correctamente.");
        return false;
    }
    else if(isNaN(G2.value)||!/^[2-9]$/.test(G2.value)){
        alert("Formulario no completo correctamente.");
        return false;
    }
    else{
        let sec=document.getElementById("datos");
        let enf=document.getElementById("enfrentamientos");
        sec.style.display="none";
        enf.style.display="inline";
        let tit=document.querySelector("#enfrentamientos h2");
        let nh2=document.createElement("h2");
        let tex=document.createTextNode("MUNDIAL " + f.mundial.value);
        nh2.append(tex);
        enf.replaceChild(nh2,tit);
        let Octv=document.getElementById("orange");
        Octv.onclick=Simulacion;
    }           
    return false;
}
function Simulacion(){
    let f=document.intro;
    let G1=f.goles_1;
    let G2=f.goles_2;
    let bCuartos=document.getElementById("green");
    let bOctavos=document.getElementById("orange");
    bOctavos.style.display="none";  
    bCuartos.style.display="inline";
    //enfrentamientos   
    let secEnfre=document.getElementById("enfrentamientos"); 
    secEnfre.style.backgroundColor="bisque"; 
    let obj=secEnfre.children;
    for(let k=0;k<obj.length;k++){
        if(obj[k].nodeName=="HR"){
            secEnfre.removeChild(obj[k]);
        }
    }
    //resultado    
    let caja=document.getElementById("resultado");
    let div=document.getElementsByTagName("div");
    let h1=document.createElement("h1");
    let encabezado=bOctavos.value;
    h1.append(encabezado);
    h1.style.backgroundColor="black";
    h1.style.color="white";
    h1.style.padding="2px";
    h1.style.textAlign="center";
    caja.appendChild(h1);
    for(let i=0;i<div.length;i+=2){ 
        if(i<div.length-1){
            let p=document.createElement("p");
            let color=bOctavos.getAttribute("id");
            p.style.border="3px solid";
            p.style.borderColor=color;
            let num=Math.round(Math.random()*G1.value);
            let num2=Math.round(Math.random()*G2.value);
            let img=document.createElement("img");
            let elem=div[i].firstElementChild.getAttribute("src");
            img.src=elem;
            let t=document.createTextNode(div[i].textContent+": "+num);
            let img2=document.createElement("img");
            let elem2=div[i+1].firstElementChild.getAttribute("src");
            img2.src=elem2;
            let t2=document.createTextNode(div[i+1].textContent+": "+num2);
            let t3=document.createTextNode(" **** ");
            p.append(img);
            p.append(t);
            p.append(t3);
            p.append(img2);
            p.append(t2);
            caja.appendChild(p); 
            if(num==num2){
                let t4=document.createTextNode(" (Ganó en penaltis)");
                div[i+1].setAttribute("id","win");
                p.append(t4);
            }           
            if(num>num2){                
                div[i].setAttribute("id","win");
            }
            if(num<num2){
                div[i+1].setAttribute("id","win");
            }
        }                     
    } 
    Cuartos();
}
function Cuartos(){
    let secEnfre=document.getElementById("enfrentamientos");
    secEnfre.style.backgroundColor="bisque"; 
    let bCuartos=document.getElementById("green");
    bCuartos.style.marginLeft="auto";
    bCuartos.style.marginRight="auto";
    bCuartos.style.display="inline";
    let hr=document.createElement("hr");
    let div=document.querySelectorAll("div");
    for(let i=0;i<div.length;i++){
        hr=document.createElement("hr");
        if(div[i].getAttribute("id")!="win"){
            secEnfre.removeChild(div[i]);
        }       
    }
    div=document.querySelectorAll("div");
    for(let k=0;k<div.length;k+=2){
        hr=document.createElement("hr");
        secEnfre.insertBefore(hr,div[k]);      
    }
    bCuartos.onclick=Semifinal;
}
function Semifinal(){
    let f=document.intro;
    let G1=f.goles_1;
    let G2=f.goles_2;
    let caja=document.getElementById("resultado");
    let bCuartos=document.getElementById("green");
    let bSemi=document.getElementById("blue");
    bCuartos.style.display="none";
    bSemi.style.display="inline";
     //enfrentamientos   
     let secEnfre=document.getElementById("enfrentamientos");  
     let obj=secEnfre.children;
     for(let k=0;k<obj.length;k++){
         if(obj[k].nodeName=="HR"){
             secEnfre.removeChild(obj[k]);
         }
         if(obj[k].getAttribute("id")=="win"){
             obj[k].setAttribute("id","");
         }
     }
    //resultado    
    let div=document.getElementsByTagName("div");
    let h1=document.createElement("h1");
    let encabezado=bCuartos.value;
    h1.append(encabezado);
    h1.style.backgroundColor="black";
    h1.style.color="white";
    h1.style.padding="2px";
    h1.style.textAlign="center";
    caja.appendChild(h1);
    for(let i=0;i<div.length;i+=2){ 
        if(i<div.length-1){
            let p=document.createElement("p");
            let color=bCuartos.getAttribute("id");
            p.style.border="3px solid";
            p.style.borderColor=color;
            let num=Math.round(Math.random()*G1.value);
            let num2=Math.round(Math.random()*G2.value);
            let img=document.createElement("img");
            let elem=div[i].firstElementChild.getAttribute("src");
            img.src=elem;
            let t=document.createTextNode(div[i].textContent+": "+num);
            let img2=document.createElement("img");
            let elem2=div[i+1].firstElementChild.getAttribute("src");
            img2.src=elem2;
            let t2=document.createTextNode(div[i+1].textContent+": "+num2);
            let t3=document.createTextNode(" **** ");
            p.append(img);
            p.append(t);
            p.append(t3);
            p.append(img2);
            p.append(t2);
            caja.appendChild(p); 
            if(num==num2){
                let t4=document.createTextNode(" (Ganó en penaltis)");
                div[i+1].setAttribute("id","win");
                p.append(t4);
            }           
            if(num>num2){                
                div[i].setAttribute("id","win");
            }
            if(num<num2){
                div[i+1].setAttribute("id","win");
            }
        }                     
    } 
SemiFinal();
}
function SemiFinal(){ 
    let secEnfre=document.getElementById("enfrentamientos"); 
    let bCuartos=document.getElementById("green"); 
    let bSemi=document.getElementById("blue");
    bCuartos.style.display="none";
    bSemi.style.display="inline";
    let hr=document.createElement("hr");
    let div=document.querySelectorAll("div");
    for(let i=0;i<div.length;i++){
        if(div[i].getAttribute("id")!="win"){
            secEnfre.removeChild(div[i]);
        }       
    }
    div=document.querySelectorAll("div");
    for(let k=0;k<div.length;k+=2){
        hr=document.createElement("hr");
        secEnfre.insertBefore(hr,div[k]);      
    }
    bSemi.onclick=Final;
}
function Final(){
    let bSemi=document.getElementById("blue");
    bSemi.style.display="none";
    let bFinal=document.getElementById("red");
    bFinal.style.display="inline"
    let f=document.intro;
    let G1=f.goles_1;
    let G2=f.goles_2;
    let caja=document.getElementById("resultado");
     //enfrentamientos   
     let secEnfre=document.getElementById("enfrentamientos");  
     let obj=secEnfre.children;
     for(let k=0;k<obj.length;k++){
         if(obj[k].nodeName=="HR"){
             secEnfre.removeChild(obj[k]);
         }
         if(obj[k].getAttribute("id")=="win"){
             obj[k].setAttribute("id","");
         }
     }
    //resultado    
    let div=document.getElementsByTagName("div");
    let h1=document.createElement("h1");
    let encabezado=bSemi.value;
    h1.append(encabezado);
    h1.style.backgroundColor="black";
    h1.style.color="white";
    h1.style.padding="2px";
    h1.style.textAlign="center";
    caja.appendChild(h1);
    for(let i=0;i<div.length;i+=2){ 
        if(i<div.length-1){
            let p=document.createElement("p");
            let color=bSemi.getAttribute("id");
            p.style.border="3px solid";
            p.style.borderColor=color;
            let num=Math.round(Math.random()*G1.value);
            let num2=Math.round(Math.random()*G2.value);
            let img=document.createElement("img");
            let elem=div[i].firstElementChild.getAttribute("src");
            img.src=elem;
            let t=document.createTextNode(div[i].textContent+": "+num);
            let img2=document.createElement("img");
            let elem2=div[i+1].firstElementChild.getAttribute("src");
            img2.src=elem2;
            let t2=document.createTextNode(div[i+1].textContent+": "+num2);
            let t3=document.createTextNode(" **** ");
            p.append(img);
            p.append(t);
            p.append(t3);
            p.append(img2);
            p.append(t2);
            caja.appendChild(p); 
            if(num==num2){
                let t4=document.createTextNode(" (Ganó en penaltis)");
                div[i+1].setAttribute("id","win");
                p.append(t4);
            }           
            if(num>num2){                
                div[i].setAttribute("id","win");
            }
            if(num<num2){
                div[i+1].setAttribute("id","win");
            }
        }                     
    } 
    Resultado();
}
function Resultado(){
    let secEnfre=document.getElementById("enfrentamientos"); 
    let bFinal=document.getElementById("red"); 
    let bSemi=document.getElementById("blue");
    bSemi.style.display="none";
    bFinal.style.display="inline";
    let hr=document.createElement("hr");
    let div=document.querySelectorAll("div");
    for(let i=0;i<div.length;i++){
        if(div[i].getAttribute("id")!="win"){
            secEnfre.removeChild(div[i]);
        }       
    }
    div=document.querySelectorAll("div");
    for(let k=0;k<div.length;k+=2){
        hr=document.createElement("hr");
        secEnfre.insertBefore(hr,div[k]);      
    }
    bFinal.onclick=Ultimo;
}
function Ultimo(){
    let bFinal=document.getElementById("red");
    bFinal.style.display="inline"
    let f=document.intro;
    let G1=f.goles_1;
    let G2=f.goles_2;
    let caja=document.getElementById("resultado");
     //enfrentamientos   
     let secEnfre=document.getElementById("enfrentamientos");  
     let obj=secEnfre.children;
     for(let k=0;k<obj.length;k++){
         if(obj[k].nodeName=="HR"){
             secEnfre.removeChild(obj[k]);
         }
         if(obj[k].getAttribute("id")=="win"){
             obj[k].setAttribute("id","");
         }
     }
    //resultado    
    let div=document.getElementsByTagName("div");
    let h1=document.createElement("h1");
    let encabezado=bFinal.value;
    h1.append(encabezado);
    h1.style.backgroundColor="black";
    h1.style.color="white";
    h1.style.padding="2px";
    h1.style.textAlign="center";
    caja.appendChild(h1);
    for(let i=0;i<div.length;i+=2){ 
        if(i<div.length-1){
            let p=document.createElement("p");
            let color=bFinal.getAttribute("id");
            p.style.border="3px solid";
            p.style.borderColor=color;
            let num=Math.round(Math.random()*G1.value);
            let num2=Math.round(Math.random()*G2.value);
            let img=document.createElement("img");
            let elem=div[i].firstElementChild.getAttribute("src");
            img.src=elem;
            let t=document.createTextNode(div[i].textContent+": "+num);
            let img2=document.createElement("img");
            let elem2=div[i+1].firstElementChild.getAttribute("src");
            img2.src=elem2;
            let t2=document.createTextNode(div[i+1].textContent+": "+num2);
            let t3=document.createTextNode(" **** ");
            p.append(img);
            p.append(t);
            p.append(t3);
            p.append(img2);
            p.append(t2);
            caja.appendChild(p); 
            if(num==num2){
                let t4=document.createTextNode(" (Ganó en penaltis)");
                div[i+1].setAttribute("id","win");
                p.append(t4);
            }           
            if(num>num2){                
                div[i].setAttribute("id","win");
            }
            if(num<num2){
                div[i+1].setAttribute("id","win");
            }
        }                     
    } 
    Fin();
}
function Fin(){
    let secEnfre=document.getElementById("enfrentamientos"); 
    let bFinal=document.getElementById("red"); 
    bFinal.style.display="none";
    let hr=document.createElement("hr");
    let div=document.querySelectorAll("div");
    for(let i=0;i<div.length;i++){
        if(div[i].getAttribute("id")!="win"){
            secEnfre.removeChild(div[i]);
        }       
    }
    div=document.querySelectorAll("div");
    for(let k=0;k<div.length;k+=2){
        hr=document.createElement("hr");
        secEnfre.insertBefore(hr,div[k]);      
    }
    Aviso();
}
function Aviso(){
    let div=document.querySelectorAll("div");
    alert("Campeón del Mundo :"+div[0].textContent);
}